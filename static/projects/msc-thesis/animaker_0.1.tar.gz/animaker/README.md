animaker
========

Generate animation timelines in R