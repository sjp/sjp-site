
source("gmdata.R")

continentCols <- cols$colours
names(continentCols) <- cols$continent

library(grid)
library(gridSVG)
library(ggplot2)

source("ggplotScale.R")

xCols <- grep("[.]x$", names(all))
yCols <- grep("[.]y$", names(all))

dev.off()

# Single-panel qplot
###########################
dev.new()
print(
ggplot(data=all) +
      geom_point(aes(x=X1950.x, y=X1950.y, size=radius,                    
                     colour=continent),
                 shape=16, alpha=.5) +
      scale_x_continuous(limits=c(1, 9),
                         name="Fertility\n(# children per woman)") +
      scale_y_continuous(limits=c(10, 90),
                         name="Life Expectancy (at birth)") +
      scale_colour_manual(values=continentCols) +
      theme(legend.position="none") +
      scale_size(range=c(1, 20))
)

# Try to animate
grid.set("geom_point", grep=TRUE,
         animateGrob(grid.get("geom_point", grep=TRUE),
                     duration=20,
                     x=t(ggplotScaleX(as.matrix(all[xCols]),
                                      1, 9)),
                     y=t(ggplotScaleY(as.matrix(all[yCols]),
                                      10, 90))))

# Add text label for year
years <- 1950:2009
visibility <- matrix("hidden", nrow=length(years), ncol=length(years))
diag(visibility) <- "visible"
yearText <- animateGrob(garnishGrob(textGrob(years, .9, .05,
                                             name="year",
                                             gp=gpar(cex=2, col="grey")),
                                    visibility="hidden"),
                        duration=20,
                        visibility=visibility)
grid.draw(yearText)

grid.export("gapminderOnePanel.svg")
dev.off()

# Multi-panel lattice plot
###########################
x11(width=10, height=7)
print(
ggplot(data=all) +
      geom_point(aes(x=X1950.x, y=X1950.y, size=radius,                    
                     colour=continent),
                 shape=16, alpha=.5) +
      scale_x_continuous(limits=c(1, 9),
                         name="Fertility\n(# children per woman)") +
      scale_y_continuous(limits=c(10, 90),
                         name="Life Expectancy (at birth)") +
      scale_colour_manual(values=continentCols) +
      theme(legend.position="none") +
      facet_wrap(~ continent) +
      scale_size(range=c(1, 20))
)

# Try to animate
grobs <- grid.get("geom_point", grep=TRUE, global=TRUE)
# Mimick the ordering induced by facet_wrap
continents <- sort(unique(all$continent))#matrix(unique(all$continent), byrow=TRUE, ncol=3)
for (i in seq_along(continents)) {
    xvals <- t(ggplotScaleX(as.matrix(all[all$continent == continents[i], xCols]), 1, 9))
    yvals <- t(ggplotScaleX(as.matrix(all[all$continent == continents[i], yCols]), 10, 90))
    grid.set(grobs[[i]]$name,
             animateGrob(grobs[[i]],
                         x=animUnit(unit(c(xvals), "npc"),
                                    id = rep(seq_len(ncol(xvals)),
                                             each = nrow(xvals))),
                         y=animUnit(unit(c(yvals), "npc"),
                                    id = rep(seq_len(ncol(yvals)),
                                             each = nrow(yvals))),
                         duration=20),
             redraw=FALSE)
}

# Add text label for year
years <- 1950:2009
visibility <- matrix("hidden", nrow=length(years), ncol=length(years))
diag(visibility) <- "visible"
yearText <- animateGrob(garnishGrob(textGrob(years, .9, .05,
                                             name="year",
                                             gp=gpar(cex=2, col="grey")),
                                    visibility="hidden"),
                        duration=20,
                        visibility=visibility)
grid.draw(yearText)

grid.export("gapminderMultiPanel.svg")
dev.off()
