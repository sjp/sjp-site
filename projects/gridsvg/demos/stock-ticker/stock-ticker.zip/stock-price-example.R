# Prerequisite checks
if (!require(gridSVG))
    install.packages("gridSVG")
# Check that we can "force" the scene using a forked gtable
if (packageDescription("gtable")$Maintainer !=
    "Paul Murrell <paul@stat.auckland.ac.nz>") {
    if (!require(devtools))
        install.packages("devtools")
    devtools::install_github("pmur002/gtable")
}
if (!require(ggplot2))
    install.packages("ggplot2")

library(gridSVG)
library(grid)
library(scales)
library(ggplot2)

aapl <- read.csv("aapl.csv")
aapl$Date <- as.Date(aapl$Date, format = "%d-%b-%y")

goog <- read.csv("goog.csv")
goog$Date <- as.Date(goog$Date, format = "%d-%b-%y")

amzn <- read.csv("amzn.csv")
amzn$Date <- as.Date(amzn$Date, format = "%d-%b-%y")

msft <- read.csv("msft.csv")
msft$Date <- as.Date(msft$Date, format = "%d-%b-%y")

stockprices.df <- rbind(aapl, amzn, goog, msft)

qplot(Date, Close, data = stockprices.df, group = Code, geom = "line",
      colour = Code) +
    scale_y_log10(breaks = trans_breaks('log10', function(x) 10^x),
                  labels = trans_format('log10', math_format(10^.x)))

# Find out what the name of the polyline is
grid.force()
grid.ls()

# Get the polyline
g <- grid.get("GRID.polyline.1")
gx <- split(g$x, g$id)
gy <- split(g$y, g$id)
nTimeIntervals <- length(gx[[1]])
nPointsOverTime <- nTimeIntervals^2
nGroups <- length(unique(g$id))

animid <- rep(1:4, each = nPointsOverTime)
animx <- numeric(nPointsOverTime * nGroups)
animy <- numeric(nPointsOverTime * nGroups)

for (i in seq_len(nGroups)) {
  xs <- as.numeric(gx[[i]])
  ys <- as.numeric(gy[[i]])

  indexRange <- (i - 1) * (length(xs) * length(xs)) + seq_along(rep(xs, length(xs)))
  newxs <- numeric(length(indexRange))
  newys <- numeric(length(indexRange))

  for (j in seq_along(xs)) {
    currentIndexRange <- (j - 1) * length(xs) + seq_along(xs)
    newxs[currentIndexRange] <- c(xs[seq_len(j)], rep(xs[j], length(xs) - j))
    newys[currentIndexRange] <- c(ys[seq_len(j)], rep(ys[j], length(ys) - j))
  }

  animx[indexRange] <- newxs
  animy[indexRange] <- newys
}

unitxs <- animUnit(unit(animx, "native"),
                   timeid = rep(seq_len(nTimeIntervals),
                                nTimeIntervals * nGroups),
                   id = rep(seq_len(nGroups),
                            each = nPointsOverTime))
unitys <- animUnit(unit(animy, "native"),
                   timeid = rep(seq_len(nTimeIntervals),
                                nTimeIntervals * nGroups),
                   id = rep(seq_len(nGroups),
                            each = nPointsOverTime))

grid.animate("GRID.polyline.1", x = unitxs, y = unitys,
             duration = 30, rep = TRUE)
grid.export("animatedStocks.svg", annotate = F, indent = F)

